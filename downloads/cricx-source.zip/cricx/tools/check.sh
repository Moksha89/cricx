#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ -d /workspace/tooling/config ]]; then
  export XDG_CONFIG_HOME=/workspace/tooling/config
  export XDG_DATA_HOME=/workspace/tooling/data
  export XDG_CACHE_HOME=/workspace/tooling/cache
fi
godot --headless --editor --import --quit > /tmp/cricx-check-import.log 2>&1
if rg -n 'SCRIPT ERROR|ERROR:' /tmp/cricx-check-import.log; then exit 1; fi
for suite in physics delivery bowling_nets; do
  check_status=0
  godot --headless --script "res://tests/${suite}_test.gd" > "/tmp/cricx-check-${suite}.log" 2>&1 || check_status=$?
  cat "/tmp/cricx-check-${suite}.log"
  if [[ "$check_status" -ne 0 ]]; then exit "$check_status"; fi
  if rg -n 'SCRIPT ERROR|ERROR:' "/tmp/cricx-check-${suite}.log"; then exit 1; fi
done
